<?php
session_start();
header('Content-Type: application/json');

if (isset($_SESSION['user'])) {
    echo json_encode(['status' => 'success', 'user' => $_SESSION['user']['username']]);
} else {
    echo json_encode(['status' => 'error', 'message' => '未登录']);
}
?>