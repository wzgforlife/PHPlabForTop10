document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('login-form');
    const loginMessage = document.getElementById('login-message');
    const initDbButton = document.getElementById('init-db');

    // 登录功能
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(loginForm);
            fetch('login/login.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = data.redirectUrl;
                } else {
                    loginMessage.textContent = data.message;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                loginMessage.textContent = '登录过程中出现错误，请重试。';
            });
        });
    }

    // 初始化数据库功能
    if (initDbButton) {
        initDbButton.addEventListener('click', function() {
            fetch('init_db.php')
                .then(response => response.text())
                .then(data => {
                    alert(data);
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('初始化数据库过程中出现错误');
                });
        });
    }
});