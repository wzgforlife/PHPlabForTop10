<?php
session_start();
header('Content-Type: text/html; charset=utf-8');

// 检查用户是否已登录
if (!isset($_SESSION['user'])) {
    header('Location: ../index.html');
    exit;
}

// 获取当前用户的用户名
$currentUsername = htmlspecialchars($_SESSION['user']['username']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户中心</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }
        .user-container {
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }
        h2 {
            color: #333;
        }
        p {
            margin: 20px 0;
            color: #666;
        }
        button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            margin: 10px 0;
        }
        button:hover {
            background: #45a049;
        }
        button#logout-btn {
            background: #f44336;
        }
        button#logout-btn:hover {
            background: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="user-container">
        <h2>用户中心</h2>
        <p>欢迎，<?php echo $currentUsername; ?>!</p>
        <button id="logout-btn">退出登录</button>
        <button id="check-login">检查登录状态</button>
    </div>

    <script>
        document.getElementById('logout-btn').addEventListener('click', function() {
            fetch('../logout.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert('已退出登录');
                        window.location.href = '../index.html';
                    } else {
                        alert('退出登录失败');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('退出登录过程中出现错误');
                });
        });

        document.getElementById('check-login').addEventListener('click', function() {
            fetch('../check_login.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        alert(`已登录，用户名：${data.user}`);
                    } else {
                        alert(data.message);
                        window.location.href = '../index.html'; // 如果未登录，跳转到登录页面
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('检查登录状态过程中出现错误');
                });
        });
    </script>
</body>
</html>