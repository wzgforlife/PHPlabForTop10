<?php
session_start();
header('Content-Type: application/json');

// 数据库连接信息
$servername = "localhost";
$username = "phpweb";
$password = "phpweb";
$dbname = "phpweb";

// 创建数据库连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接
if ($conn->connect_error) {
    die(json_encode(['status' => 'error', 'message' => "连接失败: " . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // 准备SQL语句
    $stmt = $conn->prepare("SELECT id, username FROM users WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->bind_result($id, $username);
    $stmt->fetch();

    if ($username) {
        // 登录成功，设置会话
        $_SESSION['user'] = [
            'id' => $id,
            'username' => $username
        ];
        echo json_encode([
            'status' => 'success',
            'message' => '登录成功',
            'user' => $username,
            'redirectUrl' => '../user/user.php'
        ], JSON_UNESCAPED_SLASHES);
    } else {
        echo json_encode(['status' => 'error', 'message' => '用户名或密码错误']);
    }

    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => '请求方法不支持']);
}

$conn->close();
?>