<?php
$servername = "localhost";
$username = "phpweb";
$password = "phpweb";
$dbname = "phpweb";

// 创建 MySQL 连接
$conn = new mysqli($servername, $username, $password);

// 检查连接
if ($conn->connect_error) {
    die("连接失败");
}

// 检查数据库是否存在
if (!database_exists($conn, $dbname)) {
    // 创建数据库
    $sql = "CREATE DATABASE $dbname";
    if ($conn->query($sql) === TRUE) {
        echo "数据库创建成功";
    } else {
        echo "创建数据库出错";
        $conn->close();
        exit;
    }
} else {
    echo "数据库存在，跳过创建";
}

// 切换到目标数据库
$conn->select_db($dbname);

// 检查 users 表是否存在
$tableCheckSql = "SHOW TABLES LIKE 'users'";
if ($conn->query($tableCheckSql)->num_rows == 0) {
    // 创建 users 表
    $sql = "CREATE TABLE users (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(30) NOT NULL UNIQUE,
        password VARCHAR(30) NOT NULL
    )";

    if ($conn->query($sql) === TRUE) {
        echo "表创建成功";
    } else {
        echo "创建表出错";
        $conn->close();
        exit;
    }
} else {
    echo '表已经存在';
}

// 插入测试用户
$sql = "INSERT IGNORE INTO users (username, password) VALUES ('test', '123')";
if ($conn->query($sql) === TRUE && $conn->affected_rows > 0) {
    echo '插入成功';
} else {
    echo "测试用户已存在或插入时出错";
}

$conn->close();

// 辅助函数：检查数据库是否存在
function database_exists($conn, $dbname) {
    $result = $conn->query("SHOW DATABASES LIKE '$dbname'");
    return $result->num_rows > 0;
}
?>